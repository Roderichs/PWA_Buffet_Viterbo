<?php

namespace App\Controllers;
use App\Models\Platillo;
use App\Models\Comentario;

class Home extends BaseController
{
    public function index()
    {
        $platillos = new Platillo();
        $datos['platillos'] = $platillos->orderBy('id','ASC')->findAll();
        return view('homes', $datos);
    }
}