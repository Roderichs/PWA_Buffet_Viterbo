</div>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <div class='define'>
            <div class="container">
                <div class="col-md-4 d-flex align-items-center">
                        <a href="/" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1">
                            <svg class="bi" width="30" height="24"><use xlink:href="#bootstrap"/></svg>
                        </a>
                    <span class="text-muted">&copy; 2021 LoopDesign, Roderíck</span>
                </div>
            </div>
        </div>
    </footer>

    </body>

    <style>
        section {
            overflow: auto;
            padding-bottom: 60px;
            padding-top:30px;
        }

        footer {
            position: relative;
            margin-top: -50px;
            height: 40px;
            padding:5px 0px;
            clear: both;
            background: #fff;
            text-align: center;
            color: #fff;
        }

        .define {
            width:960px;
            margin:0 auto;
        }
    </style>

    </html>